"use strict";

var referee = require("referee");
var assert = referee.assert;

describe("hello world", function () {
    it("hello world test", function () {
        assert(true);
    });
});
