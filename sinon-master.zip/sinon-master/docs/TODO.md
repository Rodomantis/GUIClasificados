# TODO for new documentation site

* TOC in each file
* Build new site using [`Jekyll`](http://jekyllrb.com)
* Verify that there are anchors for everything
* Build documentation for 1.17.x
* Build changelong for each release
* Updating CONTRIBUTING.md
* Use consistent quoting in examples
* Specify which versions of IE are supported, and where you need to load `sinon-ie.js`
* Register a twitter account for sinonjs and automatically tweet when a new release is deployed
* Add link verification
